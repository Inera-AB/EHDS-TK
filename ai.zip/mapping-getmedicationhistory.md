# GetMedicationHistory – Läkemedel - Inera EHDS Tjänstekontrakt – FHIR Implementation Guide v0.3.3

* [**Table of Contents**](toc.md)
* **GetMedicationHistory – Läkemedel**

## GetMedicationHistory – Läkemedel

# GetMedicationHistory – Läkemedelshistorik

**Tjänstekontrakt:** `clinicalprocess:activityprescription:actoutcome` GetMedicationHistory v2.2
 **FHIR-profil:** [SEEHDSMedicationStatement](StructureDefinition-SEEHDSMedicationStatement.md)
 **Logisk modell:** [SEEHDSLMMedicationHistory](StructureDefinition-SEEHDSLMMedicationHistory.md)
 **Krävs för NPÖ:** Ja (v2.2) | **Krävs för 1177 Journal:** Ja (v2.2)
 **EHDS-koppling:** Patient Summary – Aktuella läkemedel. EHDS har även separata domäner för ePrescription och eDispensation.

-------

> **VIKTIGT – Namnkonvention för PDL-fält i detta TK**I GetMedicationHistory v2.2 används **lowercase 'c'** i kamelnotationen för PDL-fälten: `healthcareProfessional**c**areUnitHSAId` och `healthcareProfessional**c**areGiverHSAId` (inte `healthcareProfessionalCareUnitHSAId` med versalt 'C' som i de flesta andra TK:er). Detta är en känd avvikelse i TKB:n och måste hanteras explicit i bryggkoden.

-------

## Resurshierarki

```
SEEHDSMedicationStatement (1 per medicationMedicalRecord)
  └── informationSource → PractitionerRole (accountableHealthcareProfessional)
  └── medicationCodeableConcept (drug, 5 XOR-varianter)
  └── basedOn → (logisk referens om koppling till recept/SIL finns)

```

Varje `medicationMedicalRecord`-post ger upphov till en `MedicationStatement`. Relationer mellan ordinationer (`prescriptionChainId`, `precedingPrescriptionId`, `succeedingPrescriptionId`) representeras via extensions – se [MED-001](#öppna-frågor).

-------

## Mappningstabell – medicationMedicalRecordHeader

| | | | |
| :--- | :--- | :--- | :--- |
| `medicationMedicalRecordHeader.documentId` | 1..1 | `MedicationStatement.identifier[0].value` | Källsystemets dokumentidentifierare |
| `medicationMedicalRecordHeader.sourceSystemHSAId` | 1..1 | `MedicationStatement.meta.source` | Format:`https://tjanstekatalogen.inera.se/Endpoint/{hsaId}` |
| `medicationMedicalRecordHeader.documentTitle` | 0..0 | Ej mappad | Ej tillämpligt för detta TK (markerat 0..0 i logisk modell) |
| `medicationMedicalRecordHeader.patientId.extension` | 1..1 | `MedicationStatement.subject.identifier.value` | Personnummer eller samordningsnummer |
| `medicationMedicalRecordHeader.patientId.root` | 1..1 | `MedicationStatement.subject.identifier.system` | OID→URI, se tabell nedan |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.authorTime` | 1..1 | `MedicationStatement.dateAsserted` | YYYYMMDDHHMMSS → ISO 8601 (Europe/Stockholm), se[GENERAL-001](#öppna-frågor) |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalHSAId` | 0..1 | `MedicationStatement.informationSource`(Reference(PractitionerRole)) | Logisk referens via HSA-id |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalName` | 0..1 | `PractitionerRole.practitioner.display` | Visningsnamn för ansvarig yrkesutövare |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalRoleCode` | 0..1 | `PractitionerRole.code` | Yrkesrollskod |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitHSAId` | 0..1 | `PractitionerRole.organization.identifier.value` | Organisationsenhetens HSA-id |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitName` | 0..1 | `PractitionerRole.organization.display` | Organisationsenhetens namn |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitTelecom` | 0..1 | Ej mappad | Telefon till organisationsenhet – MedicationStatement saknar adressfält; inkluderas ej i FHIR-resursen |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitEmail` | 0..1 | Ej mappad | E-post till organisationsenhet – se orgUnitTelecom ovan |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitAddress` | 0..1 | Ej mappad | Postadress – se orgUnitTelecom ovan |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalOrgUnit.orgUnitLocation` | 0..1 | Ej mappad | Plats/ort – se orgUnitTelecom ovan |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareGiverHSAId` | 0..1 | `Provenance.agent[custodian].who.identifier` | **Yttre Sparr**– lowercase 'c' i 'care' (TK-specifik stavning) |
| `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareUnitHSAId` | 0..1 | `Provenance.agent[author].who.identifier` | **Inre Sparr**– lowercase 'c' i 'care' (TK-specifik stavning) |
| `medicationMedicalRecordHeader.legalAuthenticator.signatureTime` | 1..1 (om legalAuth) | `MedicationStatement.extension[legalAuthenticator].signatureTime` | Signeringstidpunkt; YYYYMMDDHHMMSS → ISO 8601 |
| `medicationMedicalRecordHeader.legalAuthenticator.legalAuthenticatorHSAId` | 0..1 | `MedicationStatement.extension[legalAuthenticator].hsaId` | HSA-id för signerare |
| `medicationMedicalRecordHeader.legalAuthenticator.legalAuthenticatorName` | 0..1 | Ej mappad | Namn i klartext – HSA-id räcker för logisk referens |
| `medicationMedicalRecordHeader.legalAuthenticator.legalAuthenticatorRoleCode` | 0..0 | N/A | Ej tillämpligt för detta TK (markerat 0..0 i logisk modell) |
| `medicationMedicalRecordHeader.nullified` | 0..0 | N/A | Ej tillämpligt för detta TK |
| `medicationMedicalRecordHeader.nullifiedReason` | 0..0 | N/A | Ej tillämpligt för detta TK |
| `medicationMedicalRecordHeader.approvedForPatient` | 1..1 | `MedicationStatement.meta.security` | PDL-kontroll – se[PDL-001](#öppna-frågor) |
| `medicationMedicalRecordHeader.careContactId` | 0..1 | `MedicationStatement.context.identifier.value` | Logisk referens till vårdkontakt |

-------

## Mappningstabell – medicationPrescription

| | | | |
| :--- | :--- | :--- | :--- |
| `medicationMedicalRecordBody.medicationPrescription.prescriptionId` | 1..1 | `MedicationStatement.identifier[1]` | Ordinationens primäridentifierare (utöver documentId i headern) |
| `medicationMedicalRecordBody.medicationPrescription.typeOfPrescription` | 1..1 | `MedicationStatement.extension[typeOfPrescription]` | I=Insättning, U=Utsättning; se[MED-002](#öppna-frågor) |
| `medicationMedicalRecordBody.medicationPrescription.prescriptionStatus` | 1..1 | `MedicationStatement.status` | Active→`active`, Inactive→`stopped`; se härledda fält |
| `medicationMedicalRecordBody.medicationPrescription.prescriptionNote` | 0..1 | `MedicationStatement.note[0].text` | Fritext anteckning om ordination |
| `medicationMedicalRecordBody.medicationPrescription.principalPrescriptionReason[i].reason` | 0..* | `MedicationStatement.reasonCode[i]` | Primär ordinationsorsak (CodeableConcept) |
| `medicationMedicalRecordBody.medicationPrescription.principalPrescriptionReason[i].otherReason` | 0..1 | `MedicationStatement.note[].text` | Fritextorsak för primär ordinationsorsak; läggs som separat anteckning |
| `medicationMedicalRecordBody.medicationPrescription.additionalPrescriptionReason[i].reason` | 0..* | `MedicationStatement.reasonCode[i]` | Ytterligare ordinationsorsak (CodeableConcept) |
| `medicationMedicalRecordBody.medicationPrescription.additionalPrescriptionReason[i].otherReason` | 0..1 | `MedicationStatement.note[].text` | Fritextorsak för ytterligare ordinationsorsak |
| `medicationMedicalRecordBody.medicationPrescription.evaluationTime` | 0..1 | `MedicationStatement.extension[evaluationTime]` | Planerad utvärderingstidpunkt; YYYYMMDDHHMMSS → ISO 8601 |
| `medicationMedicalRecordBody.medicationPrescription.treatmentPurpose` | 0..1 | `MedicationStatement.note[].text` | Behandlingsändamål (fritext); läggs som separat anteckning |
| `medicationMedicalRecordBody.medicationPrescription.prescriptionChainId` | 0..1 | `MedicationStatement.extension[prescriptionChain].chainId` | Kedjeidentifierare för relaterade ordinationer |
| `medicationMedicalRecordBody.medicationPrescription.precedingPrescriptionId` | 0..1 | `MedicationStatement.extension[prescriptionChain].precedingId` | Föregående ordination i kedjan |
| `medicationMedicalRecordBody.medicationPrescription.succeedingPrescriptionId` | 0..1 | `MedicationStatement.extension[prescriptionChain].succeedingId` | Efterföljande ordination i kedjan |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.authorTime` | 1..1 (om prescriber) | `MedicationStatement.extension[prescriber].authorTime` | Förskrivarbeslutets tidpunkt; YYYYMMDDHHMMSS → ISO 8601 |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalHSAId` | 0..1 | `MedicationStatement.extension[prescriber].hsaId` | Förskrivarens HSA-id |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalName` | 0..1 | `MedicationStatement.extension[prescriber].name` | Förskrivarens namn |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalRoleCode` | 0..1 | `MedicationStatement.extension[prescriber].roleCode` | Förskrivarens befattningskod |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitHSAId` | 0..1 | `MedicationStatement.extension[prescriber].orgUnitHSAId` | Förskrivarens organisationsenhet (HSA-id) |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitName` | 0..1 | `MedicationStatement.extension[prescriber].orgUnitName` | Förskrivarens organisationsenhet (namn) |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitTelecom` | 0..1 | Ej mappad | Förskrivarens org-telefon – kontaktuppgifter lagras ej i MedicationStatement |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitEmail` | 0..1 | Ej mappad | Förskrivarens org-e-post – se orgUnitTelecom ovan |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitAddress` | 0..1 | Ej mappad | Förskrivarens org-postadress – se orgUnitTelecom ovan |
| `medicationMedicalRecordBody.medicationPrescription.prescriber.healthcareProfessionalOrgUnit.orgUnitLocation` | 0..1 | Ej mappad | Förskrivarens org-plats/ort – se orgUnitTelecom ovan |
| `medicationMedicalRecordBody.medicationPrescription.evaluator.authorTime` | 1..1 (om evaluator) | `MedicationStatement.extension[evaluator].authorTime` | Faktisk utvärderingstidpunkt; YYYYMMDDHHMMSS → ISO 8601 |
| `medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalHSAId` | 0..1 | `MedicationStatement.extension[evaluator].hsaId` | Utvärderarens HSA-id |
| `medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalName` | 0..1 | `MedicationStatement.extension[evaluator].name` | Utvärderarens namn |
| `medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalRoleCode` | 0..1 | `MedicationStatement.extension[evaluator].roleCode` | Utvärderarens befattningskod |
| `medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalOrgUnit.orgUnitHSAId` | 0..1 | `MedicationStatement.extension[evaluator].orgUnitHSAId` | Utvärderarens organisationsenhet (HSA-id) |
| `medicationMedicalRecordBody.medicationPrescription.evaluator.healthcareProfessionalOrgUnit.orgUnitName` | 0..1 | `MedicationStatement.extension[evaluator].orgUnitName` | Utvärderarens organisationsenhet (namn) |
| `medicationMedicalRecordBody.medicationPrescription.startOfFirstTreatment` | 0..1 | `MedicationStatement.extension[startOfFirstTreatment]` | Start för första behandlingsomgång; YYYYMMDDHHMMSS → ISO 8601 |
| `medicationMedicalRecordBody.medicationPrescription.startOfTreatment` | 0..1 | `MedicationStatement.effectivePeriod.start` | Behandlingsstart; YYYYMMDDHHMMSS → ISO 8601 |
| `medicationMedicalRecordBody.medicationPrescription.endOfTreatment` | 0..1 | `MedicationStatement.effectivePeriod.end` | Behandlingsslut; YYYYMMDDHHMMSS → ISO 8601 |
| `medicationMedicalRecordBody.medicationPrescription.endOfTreatmentReason` | 0..1 | `MedicationStatement.extension[endOfTreatmentReason]` | Orsak till behandlingsavslut (CodeableConcept) |
| `medicationMedicalRecordBody.medicationPrescription.selfMedication` | 1..1 | `MedicationStatement.extension[selfMedication]` | Egenmedicinering (boolean); DES-008 |
| `medicationMedicalRecordBody.medicationPrescription.dispensationAuthorization` | 0..1 | Ej mappad | Förskrivningsinformation – strukturen är ej fullt specificerad i TKB (se[MED-001](#öppna-frågor)); kan inte mappas förrän XSD-strukturen är verifierad |
| `medicationMedicalRecordBody.medicationPrescription.administration` | 0..* | Ej mappad | Administreringstillfällen – strukturen är ej fullt specificerad i TKB (se[MED-001](#öppna-frågor)); kan mappas till MedicationAdministration-resurs när XSD är verifierad |
| `medicationMedicalRecordBody.medicationPrescription.relation` | 0..* | Ej mappad | Sambandsklass – strukturen är ej fullt specificerad i TKB (se[MED-001](#öppna-frågor)); relationstyper avgör mappning när XSD är verifierad |

> **Villkor (Regel 1.8):** `prescriber`-blocket är obligatoriskt om `selfMedication = false`. `startOfTreatment` är obligatorisk om `typeOfPrescription = 'I'` (insättning).

-------

## Mappningstabell – drug (XOR-villkor)

`drug 0..1` innehåller ett av fem alternativa delelement (ömsesidigt uteslutande). Alla varianter mappas till `MedicationStatement.medicationCodeableConcept`. Se [MED-003](#öppna-frågor) för begränsning i FSH-uttrycket.

| | | | |
| :--- | :--- | :--- | :--- |
| `drug.comment` | 0..1 | `MedicationStatement.note[].text` | Kommentar om läkemedelsval; läggs som anteckning |
| `drug.unstructuredDrugInformation.unstructuredInformation` | 1..1 (om unstructured) | `MedicationStatement.medicationCodeableConcept.text` | Ostrukturerad läkemedelsinformation; ingen coding-del |
| `drug.merchandise.articleNumber` | 1..1 (om merchandise) | `MedicationStatement.medicationCodeableConcept.coding` | Handelsvara – varunummer (från SIL) som coding |
| `drug.drugArticle.nplPackId` | 1..1 (om drugArticle) | `MedicationStatement.medicationCodeableConcept.coding` | NPL förpacknings-id; system=`urn:oid:1.2.752.129.2.1.5.2` |
| `drug.drug.nplId` | 0..1 | `MedicationStatement.medicationCodeableConcept.coding` | NPL-id; system=`urn:oid:1.2.752.129.2.1.5.1` |
| `drug.drug.atcCode` | 0..1 | `MedicationStatement.medicationCodeableConcept.coding` | ATC-kod; system=`http://www.whocc.no/atc` |
| `drug.drug.routeOfAdministration` | 0..1 | `MedicationStatement.dosage[0].route` | Administreringssätt (CodeableConcept) – tas från drug-nivå och kopieras till dosage |
| `drug.drug.pharmaceuticalForm` | 0..1 | `MedicationStatement.extension[pharmaceuticalForm]` | Läkemedelsform (fritext, t.ex. "Tablett") – inget standard FHIR-fält i MedicationStatement |
| `drug.drug.strength` | 0..1 | `MedicationStatement.extension[drugStrength].value` | Styrka (decimal) – inget standard FHIR-fält i MedicationStatement |
| `drug.drug.strengthUnit` | 0..1 | `MedicationStatement.extension[drugStrength].unit` | Enhet på styrka (fritext, t.ex. "mg") |
| `drug.generics.substance` | 0..1 | `MedicationStatement.medicationCodeableConcept.text` | Substansgrupp (fritext) för generikt läkemedelsval |
| `drug.generics.strength` | 0..1 | `MedicationStatement.extension[drugStrength]` | Önskad styrka (Quantity) för generika |
| `drug.generics.form` | 0..1 | `MedicationStatement.extension[pharmaceuticalForm]` | Läkemedelsform (fritext) för generika |

-------

## Mappningstabell – dosage

`dosage 0..*` kan innehålla flera doseringsposter. Varje `dosage[i]` mappas till `MedicationStatement.dosage[i]`.

| | | | |
| :--- | :--- | :--- | :--- |
| `dosage[i].dosageInstruction` | 1..1 | `MedicationStatement.dosage[i].text` | Doseringsanvisning (fritext) |
| `dosage[i].unitDose` | 0..1 | `MedicationStatement.dosage[i].doseAndRate[0].doseQuantity` | Enhetsdos med mängd och enhet |
| `dosage[i].shortNotation` | 0..1 | `MedicationStatement.dosage[i].patientInstruction` | Kortnotation (t.ex. "1x2") |
| `dosage[i].lengthOfTreatment.treatmentInterval` | 1..1 (om lengthOfTreatment) | `MedicationStatement.dosage[i].extension[lengthOfTreatment].interval` | Tidsintervall för behandling (Range) |
| `dosage[i].lengthOfTreatment.isMaximumTreatmentTime` | 1..1 (om lengthOfTreatment) | `MedicationStatement.dosage[i].extension[lengthOfTreatment].isMaximum` | Om true: maximalt tillåten behandlingstid (boolean) |
| `dosage[i].setDosage` | 0..1 | `MedicationStatement.dosage[i].extension[setDosage]` | Komplex strukturerad dosering – fullständig struktur ej specificerad i TKB; se[MED-001](#öppna-frågor) |
| `dosage[i].maximumDosage` | 0..1 | `MedicationStatement.dosage[i].maxDosePerPeriod` | Maxdos per period – fullständig struktur ej specificerad i TKB; se[MED-001](#öppna-frågor) |
| `dosage[i].conditionalDosage.conditionDescription` | 0..1 | `MedicationStatement.dosage[i].additionalInstruction[0].text` | Villkorstext för behovsordination (fritext) |

-------

## Mappningstabell – additionalPatientInformation (om present)

| | | | |
| :--- | :--- | :--- | :--- |
| `medicationMedicalRecordBody.additionalPatientInformation.dateOfBirth` | 1..1 | `MedicationStatement.subject.birthDate` | Kräver inline Patient-resurs eller extension på subject |
| `medicationMedicalRecordBody.additionalPatientInformation.gender` | 0..1 | `MedicationStatement.subject.gender` | Administrativt kön (KV Kön OID 1.2.752.129.2.2.1.1 → AdministrativeGender). CVType-begränsning: originalText är förbjudet (0..0) per TKB. |

-------

## Mappningstabell – result (tekniska svarsfält)

`result 1..1` innehåller teknisk statusinformation som hanteras av transportlagret och inte ingår i klinisk FHIR-data.

| | | | |
| :--- | :--- | :--- | :--- |
| `result.resultCode` | 1..1 | Ej mappad | Teknisk responskod (OK/INFO/ERROR) – hanteras av transportlagret |
| `result.errorCode` | 0..1 | Ej mappad | Teknisk felkod – hanteras av transportlagret |
| `result.subcode` | 0..1 | Ej mappad | Teknisk subkod – hanteras av transportlagret |
| `result.logId` | 1..1 | Ej mappad | Teknisk spårnings-UUID – hanteras av transportlagret |
| `result.message` | 0..1 | Ej mappad | Teknisk felbeskrivning – hanteras av transportlagret |

-------

## Härledda fält / Designbeslut

### MedicationStatement.status (från prescriptionStatus + typeOfPrescription)

`prescriptionStatus` (Active/Inactive) är primär källa för `MedicationStatement.status`. `typeOfPrescription` (I/U) ger kompletterande semantik men mappar inte rakt till status-värdena – se [MED-002](#öppna-frågor). `typeOfPrescription` bevaras alltid i extension.

| | | | |
| :--- | :--- | :--- | :--- |
| `Active` | `I`(Insättning) | `active` | Ny aktiv ordination |
| `Active` | `U`(Utsättning) | `active` | Utsättningsordination, fortfarande aktiv i systemet |
| `Inactive` | `I` | `stopped` | Insättning som avslutats |
| `Inactive` | `U` | `stopped` | Avslutad utsättningsordination |

### drug XOR-villkor (MED-003)

Fem alternativa delelement under `drug 0..1` är ömsesidigt uteslutande i TKB:n. En FSH Invariant med FHIRPath implementeras i profilen som workaround.

### selfMedication (DES-008)

`selfMedication 1..1 boolean` har ingen standardiserad FHIR MedicationStatement-representation. Mappas till custom extension `https://fhir.inera.se/StructureDefinition/self-medication`.

-------

## PDL och Sparr

PDL-styrning utgår från `accountableHealthcareProfessional`-blocket i headern. **OBS:** Fältnamnen avviker från övriga TK:er med lowercase 'c' i 'care':

| | | |
| :--- | :--- | :--- |
| Yttre Sparr (vårdgivare) | `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareGiverHSAId` | `Provenance.agent[custodian].who.identifier` |
| Inre Sparr (vårdenhet) | `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareUnitHSAId` | `Provenance.agent[author].who.identifier` |
| Patientgodkännande | `medicationMedicalRecordHeader.approvedForPatient`(boolean) | `MedicationStatement.meta.security`; se[PDL-001](#öppna-frågor) |

-------

## Provenance

| | | |
| :--- | :--- | :--- |
| `agent[custodian]` | Juridiskt ansvarig vårdgivare | `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareGiverHSAId` |
| `agent[author]` | Informationsägande vårdenhet | `medicationMedicalRecordHeader.accountableHealthcareProfessional.healthcareProfessionalcareUnitHSAId` |

`Provenance.target` refererar `MedicationStatement` via `urn:uuid:{resurs.id}`.
 `Provenance.recorded` = `medicationMedicalRecordHeader.accountableHealthcareProfessional.authorTime` (ISO 8601).

-------

## OID-till-URI-tabell

| | |
| :--- | :--- |
| `1.2.752.129.2.1.3.1` | `http://electronichealth.se/identifier/personnummer` |
| `1.2.752.129.2.1.3.3` | `http://electronichealth.se/identifier/samordningsnummer` |
| `1.2.752.129.2.1.4.1` | `urn:oid:1.2.752.29.4.19` |

OID:er utan känd URI-mappning bevaras som `urn:oid:{oid}`.

-------

## Öppna frågor

| | |
| :--- | :--- |
| MED-001 | **`dispensationAuthorization`, `administration`, `relation` delvis extraherade.**Dessa element i TKB:n är markerade "SAKNAS I KÄLLDOKUMENT – endast delvis extraherat – kontrollera manuellt". Behöver verifieras mot XSD för`DispensationAuthorizationType`,`AdministrationType`,`RelationType`.`setDosage`och`maximumDosage`(komplex strukturerad dosering) ingår också i vad som behöver verifieras. Mappning läggs till när elementen är verifierade. |
| MED-002 | **`typeOfPrescription` (I/U) mappar inte naturligt till `MedicationStatement.status`.**I=Insättning och U=Utsättning anger ordinationshändelsens karaktär, inte dess aktuella status. Nuvarande beslut: bevara i extension; status härleds primärt från`prescriptionStatus`. Alternativ: ignorera`prescriptionStatus`och sätt`status=active`för I,`status=stopped`för U. |
| MED-003 | **`drug` XOR-villkor kan inte uttryckas i FSH-kardinalitet.**Fem varianter (unstructured/merchandise/drugArticle/drug/generics) är ömsesidigt uteslutande enligt TKB. FSH Invariant med FHIRPath implementeras som workaround. |
| PDL-001 | **`approvedForPatient` (boolean) saknar standardiserat FHIR-kodsystem.**Fältet mappas tentativt till`meta.security`men inget standardiserat kodsystem för detta begrepp finns. Behöver gemensamt beslut; se central issue i[mapping-issues](mapping-issues.md). |
| GENERAL-001 | **Beslutat – tidszon.**RIVTA-tidsstämplar tolkas som lokal tid i`Europe/Stockholm`(sommartid beaktas).`dateTime`får explicit offset (`+01:00`/`+02:00`);`instant`anger samma tidpunkt, helst med samma offset-form. Se[Tidsstämplar och tidszon](mappings.md#tidszon). |

## Föreslagna nya issues

| | |
| :--- | :--- |
| MED-004 | **`drug.drug.pharmaceuticalForm`, `drug.drug.strength`, `drug.drug.strengthUnit` saknar standard FHIR-element i MedicationStatement.**Dessa fält beskriver läkemedlets form och styrka på produktnivå. Överväg om de ska mappas till Medication-resurs istället för MedicationStatement-extension, i linje med FHIR-mönstret för Medication.form och Medication.ingredient.strength. |
| MED-005 | **`prescriber`-blocket kontra FHIR `requester`.**MedicationStatement.basedOn → MedicationRequest skulle vara ett mer korrekt mönster för förskrivaren om en MedicationRequest-resurs genereras. Beslut behövs om MedicationRequest ska ingå i resurshierarkin. |
| MED-006 | **`documentTitle` (header) saknar mappning.**Fritexttiteln för dokument har ingen standardmotpart i MedicationStatement. Överväg`MedicationStatement.note`eller ignorera som en rent administrativ etikett utan klinisk relevans. |

