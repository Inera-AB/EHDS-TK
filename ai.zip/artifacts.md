# Artifacts Summary - Inera EHDS Tjänstekontrakt – FHIR Implementation Guide v0.8.1

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Behavior: Capability Statements 

The following artifacts define the specific capabilities that different types of systems are expected to have in order to comply with this implementation guide. Systems conforming to this implementation guide are expected to declare conformance to one or more of the following capability statements.

| | |
| :--- | :--- |
| [SE EHDS Resource Access Provider](CapabilityStatement-SEEHDSResourceAccessProvider.md) | Krav på ett FHIR-API som tillhandahåller data från RIVTA-tjänstekontrakten enligt denna IG. Bygger på EURIDICE (EU Health Data API) Resource Access Provider och anger vilka profiler i denna IG som resurserna ska följa. |

### Structures: Logical Models 

These define data models that represent the domain covered by this implementation guide in more business-friendly terms than the underlying FHIR resources.

| | |
| :--- | :--- |
| [GetAccessLogForPatient](StructureDefinition-SEEHDSLMAccessLog.md) | Logisk modell för patientens åtkomstloggar hämtad via GetAccessLogForPatient (informationsecurity:auditing:log v1.1, 2.0). Krävs för 1177 Journal 1.1, 2.0 men ej för NPÖ. |
| [GetAccessLogsForPatient 1.1](StructureDefinition-SEEHDSLMAccessLogV11.md) | Logisk modell för version 1.1 av tjänstekontraktet GetAccessLogsForPatient (urn:riv:ehr:log:querying:GetAccessLogsForPatientResponder:1). Mappningen utgår från versionen i SEEHDSLMAccessLog. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [GetAlertInformation](StructureDefinition-SEEHDSLMAlertInformation.md) | Logisk modell för tjänstekontraktet GetAlertInformation (RIV-TA urn:riv:clinicalprocess:healthcond:description:GetAlertInformationResponder:2). Representerar responsens informationsstruktur: uppmärksamhetsinformation för en patient, exempelvis överkänslighet mot läkemedel, allvarlig sjukdom, behandling, smittsam sjukdom, vårdbegränsning eller historisk varning.Body-strukturen är XOR – exakt en av hypersensitivity, seriousDisease, treatment, communicableDisease, restrictionOfCare, unstructuredAlertInformation ska anges per post. |
| [GetAlertInformation 3.0](StructureDefinition-SEEHDSLMAlertInformationV30.md) | Logisk modell för version 3.0 av tjänstekontraktet GetAlertInformation (urn:riv:clinicalprocess:healthcond:description:GetAlertInformationResponder:3). Mappningen utgår från versionen i SEEHDSLMAlertInformation. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [GetCareContacts](StructureDefinition-SEEHDSLMCareContacts.md) | Logisk modell för tjänstekontraktet GetCareContacts (RIV-TA urn:riv:clinicalprocess:logistics:logistics:GetCareContacts:3). Representerar responsens informationsstruktur (GetCareContactsResponseType). En lista med CareContactType returneras. |
| [GetCareContacts 2.0](StructureDefinition-SEEHDSLMCareContactsV20.md) | Logisk modell för version 2.0 av tjänstekontraktet GetCareContacts (urn:riv:clinicalprocess:logistics:logistics:GetCareContactsResponder:2). Mappningen utgår från versionen i SEEHDSLMCareContacts. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [GetCareDocumentation](StructureDefinition-SEEHDSLMCareDocumentation.md) | Logisk modell för tjänstekontraktet GetCareDocumentation (RIV-TA urn:riv:clinicalprocess:healthcond:description:GetCareDocumentationResponder:3). Representerar responsens informationsstruktur: journalanteckningar för en patient. Anteckningstyper: utredning, åtgärd/behandling, sammanfattning, samordning, inskrivning, slutanteckning, anteckning utan fysiskt möte, slutenvårdsanteckning och besöksanteckning. Meddelandeformatet är kompatibelt med HL7 v3 CDA v2. |
| [GetCareDocumentation 2.1](StructureDefinition-SEEHDSLMCareDocumentationV21.md) | Logisk modell för version 2.1 av tjänstekontraktet GetCareDocumentation (urn:riv:clinicalprocess:healthcond:description:GetCareDocumentationResponder:2). Mappningen utgår från versionen i SEEHDSLMCareDocumentation. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [GetCarePlans](StructureDefinition-SEEHDSLMCarePlans.md) | Logisk modell för tjänstekontraktet GetCarePlans (RIV-TA urn:riv:clinicalprocess:logistics:logistics:GetCarePlans:2). Representerar responsens informationsstruktur (GetCarePlansResponseType). En lista med CarePlanType returneras, var och en med header- och body-element. |
| [GetDiagnosis](StructureDefinition-SEEHDSLMDiagnosis.md) | Logisk modell för tjänstekontraktet GetDiagnosis (RIV-TA urn:riv:clinicalprocess:healthcond:description:GetDiagnosisResponder:2). Representerar responsens informationsstruktur: registrerade diagnoser för en patient inklusive diagnoskod per ursprungligt diagnosticeringstillfälle. |
| [GetFunctionalStatus](StructureDefinition-SEEHDSLMFunctionalStatus.md) | Logisk modell för tjänstekontraktet GetFunctionalStatus (RIV-TA urn:riv:clinicalprocess:healthcond:description:GetFunctionalStatusResponder:2). Representerar responsens informationsstruktur: dokumenterade bedömningar av funktionsnedsättningar och/eller aktivitetsförmåga (PADL) för en patient. Bedömningskategori styrs av assessmentCategory: 'pad-pad' (PADL) eller 'fun-fun' (funktionsnedsättning). En tjänsteproducent måste använda samma värde för categorization i engagemangsindex som för assessmentCategory i svaret. |
| [GetImagingOutcome](StructureDefinition-SEEHDSLMImagingOutcome.md) | Logisk modell för tjänstekontraktet GetImagingOutcome (RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetImagingOutcome:1). Representerar responsens informationsstruktur — bilddiagnostiska resultat för en patient. Baseras på NPÖ RIV 2.2.0-specifikation. |
| [GetLaboratoryOrderOutcome](StructureDefinition-SEEHDSLMLaboratoryOrderOutcome.md) | Logisk modell för tjänstekontraktet GetLaboratoryOrderOutcome (RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetLaboratoryOrderOutcome:4). Representerar responsens informationsstruktur — multidisciplinära laboratoriesvar för en patient. |
| [GetLaboratoryOrderOutcome 3.1](StructureDefinition-SEEHDSLMLaboratoryOrderOutcomeV31.md) | Logisk modell för version 3.1 av tjänstekontraktet GetLaboratoryOrderOutcome (urn:riv:clinicalprocess:healthcond:actoutcome:GetLaboratoryOrderOutcomeResponder:3). Mappningen utgår från versionen i SEEHDSLMLaboratoryOrderOutcome. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [GetLaboratoryOrderOutcome 4.1](StructureDefinition-SEEHDSLMLaboratoryOrderOutcomeV41.md) | Logisk modell för version 4.1 av tjänstekontraktet GetLaboratoryOrderOutcome (urn:riv:clinicalprocess:healthcond:actoutcome:GetLaboratoryOrderOutcomeResponder:4). Mappningen utgår från versionen i SEEHDSLMLaboratoryOrderOutcome. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [GetMaternityMedicalHistory](StructureDefinition-SEEHDSLMMaternityMedicalHistory.md) | Logisk modell för tjänstekontraktet GetMaternityMedicalHistory (RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetMaternityMedicalHistory:2). Representerar responsens informationsstruktur — mödravårdsjournal för en patient. |
| [GetMedicationHistory](StructureDefinition-SEEHDSLMMedicationHistory.md) | Logisk modell för tjänstekontraktet GetMedicationHistory (RIV-TA urn:riv:clinicalprocess:activityprescription:actoutcome:GetMedicationHistoryResponder:2). Representerar responsens informationsstruktur — läkemedelshistorik per patient.OBS: Kontraktet är tämligen omfattande. Se tillämpningsanvisningen (AB_clinicalprocess_activityprescription_actoutcome.docx) för implementationsdetaljer. |
| [GetObservations](StructureDefinition-SEEHDSLMObservations.md) | Logisk modell för tjänstekontraktet GetObservations (RIV-TA urn:riv:clinicalprocess:healthcond:basic:GetObservationsInteraction:2). Representerar responsens informationsstruktur — en samling observationer som matchar sökkriterier i begäran, inklusive header-information. Meddelandemodellen från avsnitt 5.1 V-MIM — Observationer i TKB motsvarar en observation i svarsmeddelandet. |
| [GetObservations 1.2](StructureDefinition-SEEHDSLMObservationsV12.md) | Logisk modell för version 1.2 av tjänstekontraktet GetObservations (urn:riv:clinicalprocess:healthcond:basic:GetObservationsResponder:1). Mappningen utgår från versionen i SEEHDSLMObservations. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [GetReferralOutcome](StructureDefinition-SEEHDSLMReferralOutcome.md) | Logisk modell för tjänstekontraktet GetReferralOutcome (RIV-TA urn:riv:clinicalprocess:healthcond:actoutcome:GetReferralOutcome:3). Representerar responsens informationsstruktur — svar på konsultationsremiss och begäran om övertagande av vårdansvar. Meddelandeformatet är kompatibelt med HL7v3 CDA v.2. |
| [GetReferralOutcome 3.1](StructureDefinition-SEEHDSLMReferralOutcomeV31.md) | Logisk modell för version 3.1 av tjänstekontraktet GetReferralOutcome (urn:riv:clinicalprocess:healthcond:actoutcome:GetReferralOutcomeResponder:3). Mappningen utgår från versionen i SEEHDSLMReferralOutcome. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [GetRequestActivities](StructureDefinition-SEEHDSLMRequestActivities.md) | Logisk modell för remisstatus och processaktiviteter hämtad via GetRequestActivities (crm:requeststatus v2.0). |
| [GetRequestActivities 1.0](StructureDefinition-SEEHDSLMRequestActivitiesV10.md) | Logisk modell för version 1.0 av tjänstekontraktet GetRequestActivities (urn:riv:crm:requeststatus:GetRequestActivitiesResponder:1). Mappningen utgår från versionen i SEEHDSLMRequestActivities. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [GetVaccinationHistory](StructureDefinition-SEEHDSLMVaccinationHistory.md) | Logisk modell för tjänstekontraktet GetVaccinationHistory (RIV-TA urn:riv:clinicalprocess:activityprescription:actoutcome:GetVaccinationHistoryResponder:2). Representerar responsens informationsstruktur — vaccinationsjournal per patient. |
| [GetVaccinationHistory 1.0](StructureDefinition-SEEHDSLMVaccinationHistoryV10.md) | Logisk modell för version 1.0 av tjänstekontraktet GetVaccinationHistory (urn:riv:clinicalprocess:activityprescription:actoutcome:GetVaccinationHistoryResponder:1). Mappningen utgår från versionen i SEEHDSLMVaccinationHistory. Skillnaderna mot den och hur de påverkar mappningen beskrivs på tjänstekontraktets mappningssida. |
| [RIV-TA CVType (clinicalprocess:activityprescription:actoutcome:1)](StructureDefinition-SEEHDSRivCVTypeActivityprescriptionActoutcome1.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:1. |
| [RIV-TA CVType (clinicalprocess:activityprescription:actoutcome:2)](StructureDefinition-SEEHDSRivCVTypeActivityprescriptionActoutcome2.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:2. |
| [RIV-TA CVType (clinicalprocess:healthcond:actoutcome:2)](StructureDefinition-SEEHDSRivCVTypeHealthcondActoutcome2.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:2. |
| [RIV-TA CVType (clinicalprocess:healthcond:actoutcome:3)](StructureDefinition-SEEHDSRivCVTypeHealthcondActoutcome3.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:3. |
| [RIV-TA CVType (clinicalprocess:healthcond:actoutcome:4)](StructureDefinition-SEEHDSRivCVTypeHealthcondActoutcome4.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:4. |
| [RIV-TA CVType (clinicalprocess:healthcond:basic:1)](StructureDefinition-SEEHDSRivCVTypeHealthcondBasic1.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:healthcond:basic:1. |
| [RIV-TA CVType (clinicalprocess:healthcond:basic:2)](StructureDefinition-SEEHDSRivCVTypeHealthcondBasic2.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:healthcond:basic:2. |
| [RIV-TA CVType (clinicalprocess:healthcond:description:2)](StructureDefinition-SEEHDSRivCVTypeHealthcondDescription2.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:healthcond:description:2. |
| [RIV-TA CVType (clinicalprocess:healthcond:description:3)](StructureDefinition-SEEHDSRivCVTypeHealthcondDescription3.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:healthcond:description:3. |
| [RIV-TA CVType (clinicalprocess:logistics:logistics:2)](StructureDefinition-SEEHDSRivCVTypeLogisticsLogistics2.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:logistics:logistics:2. |
| [RIV-TA CVType (clinicalprocess:logistics:logistics:3)](StructureDefinition-SEEHDSRivCVTypeLogisticsLogistics3.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:clinicalprocess:logistics:logistics:3. |
| [RIV-TA CVType (crm:requeststatus:2)](StructureDefinition-SEEHDSRivCVTypeCrmRequeststatus2.md) | RIV-TA-datatypen CVType i namnrymden urn:riv:crm:requeststatus:2. |
| [RIV-TA DateType](StructureDefinition-SEEHDSRivDate.md) | Datum i formatet ÅÅÅÅMMDD. Elementets värde ligger som textinnehåll i XML-elementet (representation xmlText). |
| [RIV-TA IIType (clinicalprocess:activityprescription:actoutcome:1)](StructureDefinition-SEEHDSRivIITypeActivityprescriptionActoutcome1.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:1. |
| [RIV-TA IIType (clinicalprocess:activityprescription:actoutcome:2)](StructureDefinition-SEEHDSRivIITypeActivityprescriptionActoutcome2.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:2. |
| [RIV-TA IIType (clinicalprocess:healthcond:actoutcome:3)](StructureDefinition-SEEHDSRivIITypeHealthcondActoutcome3.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:3. |
| [RIV-TA IIType (clinicalprocess:healthcond:actoutcome:4)](StructureDefinition-SEEHDSRivIITypeHealthcondActoutcome4.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:4. |
| [RIV-TA IIType (clinicalprocess:healthcond:basic:1)](StructureDefinition-SEEHDSRivIITypeHealthcondBasic1.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:clinicalprocess:healthcond:basic:1. |
| [RIV-TA IIType (clinicalprocess:healthcond:basic:2)](StructureDefinition-SEEHDSRivIITypeHealthcondBasic2.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:clinicalprocess:healthcond:basic:2. |
| [RIV-TA IIType (clinicalprocess:healthcond:description:2)](StructureDefinition-SEEHDSRivIITypeHealthcondDescription2.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:clinicalprocess:healthcond:description:2. |
| [RIV-TA IIType (clinicalprocess:healthcond:description:3)](StructureDefinition-SEEHDSRivIITypeHealthcondDescription3.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:clinicalprocess:healthcond:description:3. |
| [RIV-TA IIType (clinicalprocess:logistics:logistics:3)](StructureDefinition-SEEHDSRivIITypeLogisticsLogistics3.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:clinicalprocess:logistics:logistics:3. |
| [RIV-TA IIType (crm:requeststatus:2)](StructureDefinition-SEEHDSRivIITypeCrmRequeststatus2.md) | RIV-TA-datatypen IIType i namnrymden urn:riv:crm:requeststatus:2. |
| [RIV-TA PQIntervalType (clinicalprocess:activityprescription:actoutcome:2)](StructureDefinition-SEEHDSRivPQIntervalTypeActivityprescriptionActoutcome2.md) | RIV-TA-datatypen PQIntervalType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:2. |
| [RIV-TA PQIntervalType (clinicalprocess:healthcond:actoutcome:4)](StructureDefinition-SEEHDSRivPQIntervalTypeHealthcondActoutcome4.md) | RIV-TA-datatypen PQIntervalType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:4. |
| [RIV-TA PQIntervalType (clinicalprocess:healthcond:basic:1.2)](StructureDefinition-SEEHDSRivPQIntervalTypeHealthcondBasic12.md) | RIV-TA-datatypen PQIntervalType i namnrymden urn:riv:clinicalprocess:healthcond:basic:1.2. |
| [RIV-TA PQIntervalType (clinicalprocess:healthcond:basic:2)](StructureDefinition-SEEHDSRivPQIntervalTypeHealthcondBasic2.md) | RIV-TA-datatypen PQIntervalType i namnrymden urn:riv:clinicalprocess:healthcond:basic:2. |
| [RIV-TA PQType (clinicalprocess:activityprescription:actoutcome:1)](StructureDefinition-SEEHDSRivPQTypeActivityprescriptionActoutcome1.md) | RIV-TA-datatypen PQType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:1. |
| [RIV-TA PQType (clinicalprocess:activityprescription:actoutcome:2)](StructureDefinition-SEEHDSRivPQTypeActivityprescriptionActoutcome2.md) | RIV-TA-datatypen PQType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:2. |
| [RIV-TA PQType (clinicalprocess:healthcond:actoutcome:2)](StructureDefinition-SEEHDSRivPQTypeHealthcondActoutcome2.md) | RIV-TA-datatypen PQType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:2. |
| [RIV-TA PQType (clinicalprocess:healthcond:actoutcome:3)](StructureDefinition-SEEHDSRivPQTypeHealthcondActoutcome3.md) | RIV-TA-datatypen PQType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:3. |
| [RIV-TA PQType (clinicalprocess:healthcond:actoutcome:4)](StructureDefinition-SEEHDSRivPQTypeHealthcondActoutcome4.md) | RIV-TA-datatypen PQType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:4. |
| [RIV-TA PQType (clinicalprocess:healthcond:basic:1)](StructureDefinition-SEEHDSRivPQTypeHealthcondBasic1.md) | RIV-TA-datatypen PQType i namnrymden urn:riv:clinicalprocess:healthcond:basic:1. |
| [RIV-TA PQType (clinicalprocess:healthcond:basic:2)](StructureDefinition-SEEHDSRivPQTypeHealthcondBasic2.md) | RIV-TA-datatypen PQType i namnrymden urn:riv:clinicalprocess:healthcond:basic:2. |
| [RIV-TA PartialDateType (clinicalprocess:logistics:logistics:3)](StructureDefinition-SEEHDSRivPartialDateTypeLogisticsLogistics3.md) | RIV-TA-datatypen PartialDateType i namnrymden urn:riv:clinicalprocess:logistics:logistics:3. |
| [RIV-TA PartialTimeStampType (clinicalprocess:healthcond:basic:1)](StructureDefinition-SEEHDSRivPartialTimeStampTypeHealthcondBasic1.md) | RIV-TA-datatypen PartialTimeStampType i namnrymden urn:riv:clinicalprocess:healthcond:basic:1. |
| [RIV-TA PartialTimeStampType (clinicalprocess:healthcond:basic:2)](StructureDefinition-SEEHDSRivPartialTimeStampTypeHealthcondBasic2.md) | RIV-TA-datatypen PartialTimeStampType i namnrymden urn:riv:clinicalprocess:healthcond:basic:2. |
| [RIV-TA PersonIdType (clinicalprocess:activityprescription:actoutcome:1)](StructureDefinition-SEEHDSRivPersonIdTypeActivityprescriptionActoutcome1.md) | RIV-TA-datatypen PersonIdType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:1. |
| [RIV-TA PersonIdType (clinicalprocess:activityprescription:actoutcome:2)](StructureDefinition-SEEHDSRivPersonIdTypeActivityprescriptionActoutcome2.md) | RIV-TA-datatypen PersonIdType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:2. |
| [RIV-TA PersonIdType (clinicalprocess:healthcond:actoutcome:2)](StructureDefinition-SEEHDSRivPersonIdTypeHealthcondActoutcome2.md) | RIV-TA-datatypen PersonIdType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:2. |
| [RIV-TA PersonIdType (clinicalprocess:healthcond:actoutcome:3)](StructureDefinition-SEEHDSRivPersonIdTypeHealthcondActoutcome3.md) | RIV-TA-datatypen PersonIdType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:3. |
| [RIV-TA PersonIdType (clinicalprocess:healthcond:description:2)](StructureDefinition-SEEHDSRivPersonIdTypeHealthcondDescription2.md) | RIV-TA-datatypen PersonIdType i namnrymden urn:riv:clinicalprocess:healthcond:description:2. |
| [RIV-TA PersonIdType (clinicalprocess:logistics:logistics:2)](StructureDefinition-SEEHDSRivPersonIdTypeLogisticsLogistics2.md) | RIV-TA-datatypen PersonIdType i namnrymden urn:riv:clinicalprocess:logistics:logistics:2. |
| [RIV-TA PersonIdType (clinicalprocess:logistics:logistics:3)](StructureDefinition-SEEHDSRivPersonIdTypeLogisticsLogistics3.md) | RIV-TA-datatypen PersonIdType i namnrymden urn:riv:clinicalprocess:logistics:logistics:3. |
| [RIV-TA TimePeriodType (clinicalprocess:activityprescription:actoutcome:2)](StructureDefinition-SEEHDSRivTimePeriodTypeActivityprescriptionActoutcome2.md) | RIV-TA-datatypen TimePeriodType i namnrymden urn:riv:clinicalprocess:activityprescription:actoutcome:2. |
| [RIV-TA TimePeriodType (clinicalprocess:healthcond:actoutcome:3)](StructureDefinition-SEEHDSRivTimePeriodTypeHealthcondActoutcome3.md) | RIV-TA-datatypen TimePeriodType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:3. |
| [RIV-TA TimePeriodType (clinicalprocess:healthcond:actoutcome:4)](StructureDefinition-SEEHDSRivTimePeriodTypeHealthcondActoutcome4.md) | RIV-TA-datatypen TimePeriodType i namnrymden urn:riv:clinicalprocess:healthcond:actoutcome:4. |
| [RIV-TA TimePeriodType (clinicalprocess:healthcond:basic:1)](StructureDefinition-SEEHDSRivTimePeriodTypeHealthcondBasic1.md) | RIV-TA-datatypen TimePeriodType i namnrymden urn:riv:clinicalprocess:healthcond:basic:1. |
| [RIV-TA TimePeriodType (clinicalprocess:healthcond:description:2)](StructureDefinition-SEEHDSRivTimePeriodTypeHealthcondDescription2.md) | RIV-TA-datatypen TimePeriodType i namnrymden urn:riv:clinicalprocess:healthcond:description:2. |
| [RIV-TA TimePeriodType (clinicalprocess:healthcond:description:3)](StructureDefinition-SEEHDSRivTimePeriodTypeHealthcondDescription3.md) | RIV-TA-datatypen TimePeriodType i namnrymden urn:riv:clinicalprocess:healthcond:description:3. |
| [RIV-TA TimePeriodType (clinicalprocess:logistics:logistics:2)](StructureDefinition-SEEHDSRivTimePeriodTypeLogisticsLogistics2.md) | RIV-TA-datatypen TimePeriodType i namnrymden urn:riv:clinicalprocess:logistics:logistics:2. |
| [RIV-TA TimePeriodType (clinicalprocess:logistics:logistics:3)](StructureDefinition-SEEHDSRivTimePeriodTypeLogisticsLogistics3.md) | RIV-TA-datatypen TimePeriodType i namnrymden urn:riv:clinicalprocess:logistics:logistics:3. |
| [RIV-TA TimeStampType](StructureDefinition-SEEHDSRivTimeStamp.md) | Tidpunkt i formatet ÅÅÅÅMMDDttmmss (lokal svensk tid utan tidszon). Konverteras till FHIR dateTime/instant med Europe/Stockholm, se GENERAL-001. Elementets värde ligger som textinnehåll i XML-elementet (representation xmlText). |
| [RIV-TA decimaltal](StructureDefinition-SEEHDSRivDecimal.md) | Decimaltal (xs:double/xs:decimal). Elementets värde ligger som textinnehåll i XML-elementet (representation xmlText). |
| [RIV-TA heltal](StructureDefinition-SEEHDSRivInteger.md) | Heltal (xs:int/xs:integer). Elementets värde ligger som textinnehåll i XML-elementet (representation xmlText). |
| [RIV-TA text](StructureDefinition-SEEHDSRivString.md) | Textinnehåll i ett RIV-TA-element av typen xs:string eller en strängbaserad typ (t.ex. HSAIdType, kodlistor). Elementets värde ligger som textinnehåll i XML-elementet (representation xmlText). |
| [RIV-TA xs:anyURI](StructureDefinition-SEEHDSRivAnyURI.md) | URI. Elementets värde ligger som textinnehåll i XML-elementet (representation xmlText). |
| [RIV-TA xs:base64Binary](StructureDefinition-SEEHDSRivBase64Binary.md) | Base64-kodat innehåll. Elementets värde ligger som textinnehåll i XML-elementet (representation xmlText). |
| [RIV-TA xs:boolean](StructureDefinition-SEEHDSRivBoolean.md) | Sanningsvärde (true/false). Elementets värde ligger som textinnehåll i XML-elementet (representation xmlText). |
| [RIV-TA xs:dateTime](StructureDefinition-SEEHDSRivDateTime.md) | Tidpunkt enligt xs:dateTime. Lagras som text eftersom xs:dateTime tillåter tidpunkt utan tidszon. Elementets värde ligger som textinnehåll i XML-elementet (representation xmlText). |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [SE EHDS AllergyIntolerance – Allergi/överkänslighet (GetAlertInformation)](StructureDefinition-SEEHDSAllergyIntolerance.md) | Sekundär profil för allergier och överkänslighet från GetAlertInformation.Skapas ENBART när alertInformationBody = hypersensitivity. Den tillhörande SEEHDSFlag-resursen är alltid primär och pekar på denna resurs via Flag.extension[flag-detail] (standard R4-extension; R5: supportingInfo).Populeras med klinisk information från hypersensitivity-blocket:* atcSubstance/hypersensitivityAgentCode → AllergyIntolerance.code
* degreeOfSeverity → AllergyIntolerance.reaction.severity
* degreeOfCertainty → AllergyIntolerance.verificationStatus (se ALERT-004)
* ascertainedDate → AllergyIntolerance.onsetDateTime
* alertInformationComment → AllergyIntolerance.note
* pharmaceuticalProductId → AllergyIntolerance.reaction.substance.coding (NPL-id)
Täcker NPÖ 2.0 och 1177 Journal 2.0. |
| [SE EHDS AuditEvent – Innehållshämtning med patient (BALP PatientRead)](StructureDefinition-SEEHDSAuditEventPatientRead.md) | Loggpost som ska skapas när ett EHDS-kompatibelt FHIR-API (t.ex. en EHDS-brygga) lämnar ut en enskild resurs eller ett dokuments innehåll för en patient, t.ex. läsning av en resurs eller (framtida) MHD ITI-68 Retrieve Document. Loggposterna behövs för att patienten ska kunna få veta vem som har tagit del av patientens uppgifter.Ärver från IHE BALP PatientRead och lägger till:* användaragent (agent[user]) och syfte (purposeOfEvent, agent[user].purposeOfUse) är obligatoriska
* en agent per källsystem/vårdgivare som innehållet kommer från (agent[custodian])
* bryggan som loggkälla (source.observer)
 |
| [SE EHDS AuditEvent – Läsning av åtkomstloggar (GetAccessLogForPatient)](StructureDefinition-SEEHDSAuditEventReadAccessLog.md) | Profil för att läsa åtkomstloggar: representerar en befintlig loggpost som lämnas ut till patienten, mappad från RIVTA-tjänstekontraktet GetAccessLogForPatient (informationsecurity:auditing:log v1.1, 2.0). Täcker 1177 Journal 1.1, 2.0. Krävs ej för NPÖ.Profilen används INTE för att logga användningen av FHIR-API:et. De loggposter som ska skapas när API:et nyttjas beskrivs av SEEHDSAuditEventPatientQuery och SEEHDSAuditEventPatientRead. |
| [SE EHDS AuditEvent – Sökning och träfflista med patient (BALP PatientQuery)](StructureDefinition-SEEHDSAuditEventPatientQuery.md) | Loggpost som ska skapas när ett EHDS-kompatibelt FHIR-API (t.ex. en EHDS-brygga) tar emot en sökning på en patients uppgifter och lämnar ut träfflistan, t.ex. MHD ITI-67 Find Document References eller QEDm PCC-44. Loggposterna behövs för att patienten ska kunna få veta vem som har tagit del av patientens uppgifter.Ärver från IHE BALP PatientQuery och lägger till:* användaragent (agent[user]) och syfte (purposeOfEvent, agent[user].purposeOfUse) är obligatoriska
* en agent per källsystem/vårdgivare som bidrog till svaret (agent[custodian])
* bryggan som loggkälla (source.observer)
* träfflistan: varje utlämnad resurs registreras som en entity med entity.type = resurstypen (http://hl7.org/fhir/resource-types) och entity.role = object-role#4 "Domain Resource"
 |
| [SE EHDS CarePlan – Vårdplan (GetCarePlans)](StructureDefinition-SEEHDSCarePlan.md) | Profil för vård- och omsorgsplaner mappat från RIVTA-tjänstekontraktet GetCarePlans (clinicalprocess:logistics:logistics v2.0). Täcker NPÖ 2.0 och 1177 Journal 2.0. |
| [SE EHDS Composition – Strukturerad journalanteckning från DocBook (GetCareDocumentation)](StructureDefinition-SEEHDSCompositionCareDocumentation.md) | Valfri strukturerad representation av en journalanteckning från GetCareDocumentation v3.0 när innehållet är DocBook (clinicalDocumentNoteText eller en bilaga med mediaType application/docbook+xml). Varje DocBook-<section> blir en Composition.section med XHTML-narrativ (Strategi B, se DOC-004 och sidan DocBook-mappning).Kompletterar SEEHDSDocumentReference, där innehållet alltid finns som XHTML (Strategi A). Composition kopplas till DocumentReference genom att samma Provenance har båda i Provenance.target. |
| [SE EHDS Condition – Diagnos (GetDiagnosis)](StructureDefinition-SEEHDSConditionDiagnosis.md) | Profil för diagnos/problem mappat från RIVTA-tjänstekontraktet GetDiagnosis (clinicalprocess:healthcond:description v2.0). Ärver HL7 Europe Core Condition (EURIDICE). Täcker NPÖ 2.0 och 1177 Journal 2.0. |
| [SE EHDS Condition – Funktionstillstånd och ADL (GetFunctionalStatus)](StructureDefinition-SEEHDSConditionFunctional.md) | Profil för funktionstillstånd och ADL-bedömningar mappat från RIVTA-tjänstekontraktet GetFunctionalStatus (clinicalprocess:healthcond:description v2.0). Täcker NPÖ 2.0 och 1177 Journal 2.0.TKBn har två bedömningskategorier: 'pad-pad' (PADL-bedömning) och 'fun-fun' (funktionsnedsättningsbedömning med ICF-kod). Condition.code mappas mot assessmentCategory (för PADL) eller disability.disabilityAssessment (ICF-kod). Inget statusfält, tidperiod eller svårighetsgradfält finns i TKBn – dessa är härleddda. |
| [SE EHDS Device – Källsystem (GetVaccinationHistory registrationRecord)](StructureDefinition-SEEHDSDevice.md) | Profil för det källsystem som registrerat en vaccination i GetVaccinationHistory v2.0.Representerar vaccinationMedicalRecordBody.registrationRecord.sourceSystem* och sourceSystemContact. Refereras från SEEHDSImmunization via extension[registrationDevice].deviceName[systemName] = sourceSystemName (1..1, obligatorisk) deviceName[productName] = sourceSystemProductName (0..1) version = sourceSystemProductVersion (0..1) extension[sourceSystemContact] = sourceSystemContact.hsaid/personName (0..1) |
| [SE EHDS DiagnosticReport – Bilddiagnostiskt utlåtande (GetImagingOutcome)](StructureDefinition-SEEHDSDiagnosticReportImaging.md) | Profil för bilddiagnostiska utlåtanden/fynd från GetImagingOutcome. Används tillsammans med SEEHDSImagingStudy för att representera både undersökning och svar. |
| [SE EHDS DiagnosticReport – Konsultationssvar (GetReferralOutcome)](StructureDefinition-SEEHDSDiagnosticReportReferral.md) | Profil för konsultationssvar (outcome) från GetReferralOutcome. Används tillsammans med SEEHDSServiceRequestReferral. |
| [SE EHDS DiagnosticReport – Provsvar (GetLaboratoryOrderOutcome)](StructureDefinition-SEEHDSDiagnosticReportLab.md) | Profil för laboratorieresultat mappat från RIVTA-tjänstekontraktet GetLaboratoryOrderOutcome (clinicalprocess:healthcond:actoutcome v4.2). Täcker NPÖ v4.2 och 1177 Journal v4.2. |
| [SE EHDS DocumentReference – Anteckningar (GetCareDocumentation)](StructureDefinition-SEEHDSDocumentReference.md) | Profil för vårdanteckningar mappat från RIVTA-tjänstekontraktet GetCareDocumentation (clinicalprocess:healthcond:description v3.0). Täcker NPÖ 3.0 och 1177 Journal 3.0.Använder JoL-header v2.2 (ej PatientSummaryHeader): accessControlHeader för PDL, record för journaluppgift-metadata, author för dokumentationsansvarig, signature för signeringsinformation. |
| [SE EHDS Encounter – Vårdkontakter (GetCareContacts)](StructureDefinition-SEEHDSEncounter.md) | Profil för vårdkontakter mappat från RIVTA-tjänstekontraktet GetCareContacts (clinicalprocess:logistics:logistics v3.0). Täcker NPÖ 2.0, 3.0 och 1177 Journal 2.0, 3.0. |
| [SE EHDS Flag – Uppmärksamhetsinformation (GetAlertInformation)](StructureDefinition-SEEHDSFlag.md) | Primär profil för ALL uppmärksamhetsinformation från GetAlertInformation (clinicalprocess:healthcond:description v2.0).Varje alertInformation-post ger alltid en Flag-resurs. Om typeOfAlertInformation anger allergi/överkänslighet (body = hypersensitivity) skapas dessutom en SEEHDSAllergyIntolerance-resurs som pekas ut via extension[flag-detail] (standard R4-extension; kallas supportingInfo i R5).Body-strukturen är XOR: exakt en av hypersensitivity, seriousDisease, treatment, communicableDisease, restrictionOfCare, unstructuredAlertInformation anges per post.Flag.category[alertType] = typeOfAlertInformation (obligatorisk). Flag.category[hypersensitivityType] = typeOfHypersensitivity (när body = hypersensitivity). Flag.code = den kliniska koden specifik för body-typen.Täcker NPÖ 2.0 och 1177 Journal 2.0. |
| [SE EHDS ImagingStudy – Bilddiagnostik (GetImagingOutcome)](StructureDefinition-SEEHDSImagingStudy.md) | Profil för bilddiagnostiska undersökningar mappat från RIVTA-tjänstekontraktet GetImagingOutcome (clinicalprocess:healthcond:actoutcome v1.0). Täcker NPÖ 1.0 och 1177 Journal 1.0. |
| [SE EHDS Immunization – Vaccinationer (GetVaccinationHistory)](StructureDefinition-SEEHDSImmunization.md) | Profil för vaccinationer mappat från RIVTA-tjänstekontraktet GetVaccinationHistory (clinicalprocess:activityprescription:actoutcome v2.0). Täcker NPÖ 2.0 och 1177 Journal 1.0, 2.0. |
| [SE EHDS MedicationStatement – Läkemedel (GetMedicationHistory)](StructureDefinition-SEEHDSMedicationStatement.md) | Profil för läkemedelsordinationer, förskrivningar och administrerade läkemedel mappat från RIVTA-tjänstekontraktet GetMedicationHistory (clinicalprocess:activityprescription:actoutcome v2.2). Täcker NPÖ 2.2 och 1177 Journal 2.2. |
| [SE EHDS Observation Base – GetObservations](StructureDefinition-SEEHDSObservationBase.md) | Basprofil för alla observationer från GetObservations (clinicalprocess:healthcond:basic v2.0).Profilen fångar den generella TK-mappningen och används som förälder av domänspecifika profiler (t.ex. SEEHDSObservationGrowth för tillväxtkurva).Nyckeldesignbeslut:* observationBody.value är XOR-union av sju värdetyper (cv/pq/ivl_pq/ts/ivl_ts/st/int). Varje gren mappas till respektive FHIR value[x]-variant.
* Om valueNegation=true utelämnas value[x] och dataAbsentReason sätts.
* observationBody.time (ts/ivl_ts) → effective[x]; registrationTime → issued.
* participation är polymorf (healthcareProfessional/patient/otherPerson/locationRole/resource/organisation). Välj FHIR-element per deltagartyp (se mappningssida).
* PDL-fält (Sparr) hanteras via Provenance och meta.security (se mappningssida).
Täcker NPÖ 1.2 och 1177 Journal 1.2. |
| [SE EHDS Observation – Laboratoriesvar (GetLaboratoryOrderOutcome)](StructureDefinition-SEEHDSObservationLab.md) | Profil för enskilda laboratorieresultat/analyser mappat från GetLaboratoryOrderOutcome. Används i kombination med SEEHDSDiagnosticReportLab. |
| [SE EHDS Observation – Mödravård (GetMaternityMedicalHistory)](StructureDefinition-SEEHDSObservationMaternity.md) | Generisk profil för medicinsk historik inom mödravård mappat från RIVTA-tjänstekontraktet GetMaternityMedicalHistory (clinicalprocess:healthcond:actoutcome v2.0). Täcker NPÖ 2.0 och 1177 Journal 2.0.TKB:n har tre avsnitt (registrationRecord, pregnancyCheckupRecord, postDeliveryRecord). Profilen används både för den grupperande Observationen per avsnitt (code = avsnittskod, code.text = documentTitle, hasMember = fälten) och för medlems-Observationerna, en per fält (MAT-001). |
| [SE EHDS Observation – Tillväxtkurva (GetObservations + IoÖ v3)](StructureDefinition-SEEHDSObservationGrowth.md) | Profil för tillväxtobservationer (längd, vikt, huvudomfång, beräknad graviditetslängd) för barn och ungdom, baserad på:* GetObservations (clinicalprocess:healthcond:basic v2.0)
* Interaktionsöverenskommelse Tillväxtkurva för barn och ungdom v3 (Inera, 2023-05-15)
Ärver SEEHDSObservationBase och lägger till:* code bunden till GrowthObservationTypeVS (IoÖ-specificerade SNOMED CT-koder)
* value[x] begränsad till Quantity (pq-grenen; IoÖ anger alltid PQ-värden)
* Enhet (UCUM) per mättyp: cm (längd/hC), kg (vikt), d (gestationslängd)
Kodsystem för observationBody.type: SNOMED CT SE, OID 1.2.752.116.2.1.1.Täcker NPÖ 1.2 och 1177 Journal 1.2. |
| [SE EHDS Organization – Organisationsenhet](StructureDefinition-SEEHDSOrganization.md) | Profil för organisationsenheter i EHDS-TK-mappningar (vårdenheter, juridiska vårdgivare m.fl.). Ärver HL7 Europe Core Organization (EURIDICE). Identifier-slicen följer svenska basprofilernas konvention (SEBaseOrganization: slice hsaid, system urn:oid:1.2.752.29.4.19, typ PRN).Identifier-slicen ger stöd för HSA-id och SMI-id (Folkhälsomyndighetens id för vaccinationsenheter i det nationella vaccinationsregistret). Namn, kontaktuppgifter och adress mappar fält som annars inte har plats i resurserna de refereras ifrån. |
| [SE EHDS Patient](StructureDefinition-SEEHDSPatient.md) | Patientprofil för EHDS-TK. Ärver HL7 Europe Core Patient (EURIDICE) och följer svenska basprofilernas identifierarkonvention (SEBasePatient: slicarna personnummer, samordningsnummer, nationelltReservnummer). Skapas av API:et utifrån patientId i RIVTA-svaret, eftersom EU Core kräver subject.reference (GENERAL-006). |
| [SE EHDS PractitionerRole – Hälso- och sjukvårdspersonal i uppdrag](StructureDefinition-SEEHDSPractitionerRole.md) | Profil för hälso- och sjukvårdspersonal i uppdrag (medarbetaruppdrag) som refereras från EHDS-TK-resurserna (t.ex. accountableHealthcareProfessional, legalAuthenticator, author). Ärver HL7 Europe Core PractitionerRole (EURIDICE). Identifier-slicen följer svenska basprofilernas konvention (SEBasePractitionerRole: slice hsaid, system urn:oid:1.2.752.29.4.19, typ PRN). Används normalt som logisk referens via identifier. |
| [SE EHDS Provenance](StructureDefinition-SEEHDSProvenance.md) | Provenance-profil för EHDS-TK. Varje klinisk resurs åtföljs av en Provenance med två agenter som speglar spärr-hierarkin enligt PDL:* custodian (yttre Sparr) — den juridiskt ansvariga vårdgivaren
* author (inre Sparr) — den informationsägande vårdenheten
Agenterna skiljs åt på `agent.type` (diskriminator av typen pattern på `type`), som ska innehålla kodningen `provenance-participant-type#custodian` respektive `provenance-participant-type#author`. En validator kan därmed avgöra vilken agent som är vilken. Båda agenterna anges som logisk referens med HSA-id i `who.identifier`. Se GENERAL-003.OBS: Om den FHIR-server som tillhandahåller data själv hanterar åtkomstfiltrering baserat på anropande vårdpersonals kontext eller patientens e-hälsotjänst, behöver Provenance-agenterna för spärr och `meta.security` för `approvedForPatient` inte inkluderas i svaret — filtreringen sker då redan på servernivå. |
| [SE EHDS ServiceRequest – Konsultationsremiss (GetReferralOutcome)](StructureDefinition-SEEHDSServiceRequestReferral.md) | Profil för konsultationsremisser mappat från RIVTA-tjänstekontraktet GetReferralOutcome (clinicalprocess:healthcond:actoutcome v3.2). Täcker NPÖ 3.2 och 1177 Journal 3.2.Notera: GetReferralOutcome returnerar remissvaret, inte remissen i sig. Remissens metadata finns under referralOutcomeBody.referral och är begränsad till id, orsak, tid och avsändare. Inget mottagarfält, prioritet, typ eller diagnos finns i TKBn för remissens del. |
| [SE EHDS Task – Remisstatus (GetRequestActivities)](StructureDefinition-SEEHDSTask.md) | Profil för remisstatus och processaktiviteter mappat från RIVTA-tjänstekontraktet GetRequestActivities (crm:requeststatus v2.0). Täcker NPÖ 2.0 och 1177 Journal 1.0, 2.0. |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Allvarlighetsgrad för överkänslighet](StructureDefinition-alert-degree-of-severity.md) | Bedömning av överkänslighetens allvarlighetsgrad (alertInformationBody.hypersensitivity.degreeOfSeverity). KV Allvarlighetsgrad 1.2.752.129.2.2.3.3. |
| [Behandlingsbeskrivning](StructureDefinition-alert-treatment-description.md) | Beskrivning av allvarlig behandling som patienten genomgår (alertInformationBody.treatment.treatmentDescription). Behandlingskod läggs i Flag.code. |
| [Datum för konstaterande](StructureDefinition-alert-ascertained-date.md) | Datum då förhållandet som föranledde uppmärksamhetssignalen konstaterades (alertInformationBody.ascertainedDate). |
| [Fullständig dos administrerad](StructureDefinition-immunization-is-dose-complete.md) | Anger om hela den ordinerade dosen administrerades (administrationRecord.isDoseComplete). |
| [Godkänd för patient](StructureDefinition-approved-for-patient.md) | Anger om information är godkänd för delning med patient (approvedForPatient, Regel 3). |
| [Juridisk äkthetsintygsgivare för uppmärksamhetssignal](StructureDefinition-alert-asserter.md) | HSA-id för juridisk äkthetsintygsgivare (alertInformationHeader.legalAuthenticator.legalAuthenticatorHSAId). |
| [Juridisk äkthetsintygsgivare för vaccination](StructureDefinition-immunization-legal-authenticator.md) | Signeringstidpunkt och HSA-id för juridisk äkthetsintygsgivare (vaccinationMedicalRecordHeader.legalAuthenticator). |
| [Kommentar om vårdbegränsning](StructureDefinition-alert-restriction-of-care-comment.md) | Information om uppmärksammat förhållande som inte avser överkänslighet, sjukdom eller behandling (alertInformationBody.restrictionOfCare.restrictionOfCareComment). |
| [Kommentar till uppmärksamhetssignal](StructureDefinition-alert-information-comment.md) | Kommentar angående uppmärksamhetssignalen (alertInformationBody.alertInformationComment). Om obsoleteComment är angivet konkateneras det med prefix 'Inaktiveringskommentar: {obsoleteComment}'. För body = unstructuredAlertInformation: unstructuredAlertInformationContent läggs här. |
| [Kronisk diagnos](StructureDefinition-condition-chronic-diagnosis.md) | Anger om diagnosen är kronisk (true) eller inte kronisk (false) (diagnosisBody.chronicDiagnosis). Se DIAG-001. |
| [Källsystem för vaccinationsregistrering](StructureDefinition-immunization-registration-device.md) | Referens till den Device-resurs som beskriver källsystemet varifrån vaccinationsregistreringen härstammar (registrationRecord.sourceSystemName/productName/productVersion/sourceSystemContact). |
| [Källsystemskontakt](StructureDefinition-device-source-system-contact.md) | Ansvarig kontaktperson för källsystemet (registrationRecord.sourceSystemContact.hsaid/personName). |
| [Läkemedel vid behandling](StructureDefinition-alert-pharmaceutical-treatment.md) | Läkemedel som används vid uppmärksammad behandling, ATC-kod rekommenderas (alertInformationBody.treatment.pharmaceuticalTreatment). Lista med 0..* – ryms ej i Flag.code (1..1). |
| [Läkemedelsöverkänslighet – substansdetaljer](StructureDefinition-alert-pharmaceutical-hypersensitivity.md) | Kompletterande substansdetaljer för läkemedelsöverkänslighet (alertInformationBody.hypersensitivity.pharmaceuticalHypersensitivity). Primär substans: atcSubstance → Flag.code.coding; nonATCSubstance → Flag.code.text. Denna extension bär kvarvarande detaljer: nonATCSubstanceComment och pharmaceuticalProductId. |
| [Patientens postnummer vid vaccination](StructureDefinition-immunization-patient-postal-code.md) | Patientens postnummer vid vaccinationstillfället (registrationRecord.patientPostalCode). |
| [Relaterad uppmärksamhetssignal](StructureDefinition-related-alert-information.md) | Information om samband med andra uppmärksamhetssignaler (alertInformationBody.relatedAlertInformation). |
| [Signeringstidpunkt för journalanteckning](StructureDefinition-ext-signature-time.md) | Tidpunkt då journalanteckningen signerades (careDocumentation.header.signature.timestamp, JoL-header v2.2). Anges endast när signature.timestamp finns i källan; ingen ersättningstidpunkt sätts annars. Se DOC-003. |
| [Signeringstidpunkt för uppmärksamhetssignal](StructureDefinition-alert-asserted-date.md) | Tidpunkt för signering av uppmärksamhetsinformation (alertInformationHeader.legalAuthenticator.signatureTime). |
| [Smittväg](StructureDefinition-alert-route-of-transmission.md) | Kod för hur sjukdomen smittar (alertInformationBody.communicableDisease.routeOfTransmission). KV Smittväg. |
| [Tidpunkt för verifiering](StructureDefinition-alert-verified-time.md) | Tidpunkt då uppmärksamhetssignalen verifierades i det lokala systemet (alertInformationBody.verifiedTime). |
| [Visshet för överkänslighet](StructureDefinition-alert-degree-of-certainty.md) | Visshetsgrad för överkänsligheten (alertInformationBody.hypersensitivity.degreeOfCertainty). KV Visshetsgrad 1.2.752.129.2.2.3.11. |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [AssessmentCategory — ValueSet](ValueSet-assessmentcategory-vs.md) | Tillåtna värden för fältet assessmentCategory i GetFunctionalStatus. |
| [DeliveryCode — ValueSet](ValueSet-deliverycode-vs.md) | Tillåtna värden för förlossningssätt i GetMaternityMedicalHistory. |
| [DiagnosisType — ValueSet](ValueSet-diagnosistype-vs.md) | Tillåtna värden för fältet typeOfDiagnosis i GetDiagnosis: HD (huvuddiagnos) och BY (bidiagnos) från kv_diagnostyp. |
| [ErrorCode — ValueSet](ValueSet-errorcode-vs.md) | Tillåtna värden för errorCode i svar. |
| [ExaminationStatusCode — ValueSet](ValueSet-examinationstatuscode-vs.md) | Tillåtna värden för examinationStatus i GetImagingOutcome. |
| [FetalPositionCode — ValueSet](ValueSet-fetalpositioncode-vs.md) | Tillåtna värden för fosterläge i GetMaternityMedicalHistory. |
| [KV Anteckningstyp — ValueSet](ValueSet-clinicaldocumentnotecode-vs.md) | Tillåtna värden för fältet clinicalDocumentNoteCode i GetCareDocumentation enligt KV Anteckningstyp (OID: 1.2.752.129.2.2.2.11). |
| [PrescriptionStatus — ValueSet](ValueSet-prescriptionstatus-vs.md) | Tillåtna värden för prescriptionStatus i GetMedicationHistory. |
| [ReferralOutcomeTypeCode — ValueSet](ValueSet-referraloutcometypecode-vs.md) | Tillåtna värden för referralOutcomeTypeCode i GetReferralOutcome. |
| [ResultCode — ValueSet](ValueSet-resultcode-vs.md) | Tillåtna värden för resultCode i svar. |
| [SE Observation Status (SNOMED CT urval 56431000052106)](ValueSet-se-observation-status-vs.md) | Tillåtna statusvärden för GetObservations observationStatus. Urvals-id 56431000052106, SNOMED CT SE (OID 1.2.752.116.2.1.1). Mappning till FHIR ObservationStatus via ConceptMap observation-status-map. |
| [SexCode — ValueSet](ValueSet-sexcode-vs.md) | Tillåtna värden för kön i GetMaternityMedicalHistory. |
| [Tillväxtkurva – observationstyper (IoÖ Tillväxtkurva v3)](ValueSet-growth-observation-type-vs.md) | SNOMED CT-koder för tillväxtmätningar enligt Interaktionsöverenskommelse Tillväxtkurva för barn och ungdom v3 (Inera, 2023-05-15).Alla koder från kodsystemet SNOMED CT SE (OID 1.2.752.116.2.1.1).Koder:*  

| | | |
| :--- | :--- | :--- |
| 1153637007 | Kroppslängd | (primärkod för längd) |

 
*  

| | | |
| :--- | :--- | :--- |
| 50373000 | Mått på kroppslängd | (alternativkod för längd) |

 
*  

| | | |
| :--- | :--- | :--- |
| 248334005 | Längd i liggande | (bakåtkompatibel – ej för nyanslutning) |

 
*  

| | |
| :--- | :--- |
| 27113001 | Kroppsvikt |

 
*  

| | |
| :--- | :--- |
| 363812007 | Huvudomfång |

 
*  

| | |
| :--- | :--- |
| 412726003 | Graviditetslängd vid födelse |

 
 |
| [TypeOfCarePlan — ValueSet](ValueSet-typeofcareplan-vs.md) | Tillåtna värden för typeOfCarePlanEnum i GetCarePlans enligt clinicalprocess:logistics:logistics. |
| [TypeOfLeaveCode — ValueSet](ValueSet-typeofleavecode-vs.md) | Tillåtna värden för typ av ledighet i GetMaternityMedicalHistory. |
| [TypeOfPrescription — ValueSet](ValueSet-typeofprescription-vs.md) | Tillåtna värden för typeOfPrescription i GetMedicationHistory. |
| [TypeOfResultCode — ValueSet](ValueSet-typeofresultcode-vs.md) | Tillåtna värden för typeOfResult i GetImagingOutcome. |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [AssessmentCategory](CodeSystem-assessmentcategory-cs.md) | Bedömningskategori för funktionsstatus. Tillåtna värden är 'pad-pad' (PADL-bedömning) och 'fun-fun' (funktionsnedsättningsbedömning). Definierat i enum XSD v2.1 för domänen. |
| [DeliveryCode](CodeSystem-deliverycode-cs.md) | Kodverk för förlossningssätt (DeliveryCodeEnum). Används i GetMaternityMedicalHistory. |
| [ErrorCode](CodeSystem-errorcode-cs.md) | Kodverk för felkoder i svar från tjänstekontrakten i domänen clinicalprocess:activityprescription:actoutcome. |
| [ExaminationStatusCode](CodeSystem-examinationstatuscode-cs.md) | Kodverk för undersökningsstatus (ExaminationStatusCodeEnum). Används i GetImagingOutcome. |
| [FetalPositionCode](CodeSystem-fetalpositioncode-cs.md) | Kodverk för fosterläge (FetalPositionCodeEnum). Används i GetMaternityMedicalHistory. |
| [KV Anteckningstyp](CodeSystem-clinicaldocumentnotecode-cs.md) | Kodverk för typ av journalanteckning enligt KV Anteckningstyp. OID: 1.2.752.129.2.2.2.11. |
| [KV Diagnostyp (fragment)](CodeSystem-diagnosistype-cs.md) | Fragment av Ineras kodverk kv_diagnostyp med de koder som används för typ av diagnos i GetDiagnosis (diagnosisBody.typeOfDiagnosis): HD = huvuddiagnos, BY = bidiagnos. Kodverket förvaltas av Inera; detta är en delmängd för validering i IG:n. |
| [MaternityMedicalSection](CodeSystem-maternity-section.md) | Diskriminatorkoder för de tre sektionerna i mödravårdsjournalen (GetMaternityMedicalHistory v2.0). Varje Observation-resurs som skapas ur ett maternityMedicalRecord sätter Observation.code till en av dessa koder. |
| [NonReplaceable](CodeSystem-nonreplaceable-cs.md) | Kodverk för aktör som har angett att ett läkemedel inte är utbytbart i GetMedicationHistory (DispensationAuthorizationType). |
| [PrescriptionStatus](CodeSystem-prescriptionstatus-cs.md) | Kodverk för ordinationsstatus i GetMedicationHistory. Anger om en ordination är aktiv eller inaktiv. |
| [ReferralOutcomeTypeCode](CodeSystem-referraloutcometypecode-cs.md) | Kodverk för typ av remissvar (ReferralOutcomeTypeCodeEnum). Används i GetReferralOutcome. |
| [ResultCode](CodeSystem-resultcode-cs.md) | Kodverk för resultatkod i svar från tjänstekontrakten i domänen clinicalprocess:activityprescription:actoutcome. |
| [SexCode](CodeSystem-sexcode-cs.md) | Kodverk för kön (SexCodeEnum). Används i GetMaternityMedicalHistory för barnets kön. OBS: Överväg att använda HL7 AdministrativeGender istället. |
| [TypeOfCarePlan](CodeSystem-typeofcareplan-cs.md) | Typ av vård- och omsorgsplan enligt clinicalprocess:logistics:logistics v3.0. Definierad i clinicalprocess_logistics_logistics_enum_3.0.xsd. |
| [TypeOfLeaveCode](CodeSystem-typeofleavecode-cs.md) | Kodverk för typ av ledighet (TypeOfLeaveCodeEnum). Används i GetMaternityMedicalHistory. |
| [TypeOfPrescription](CodeSystem-typeofprescription-cs.md) | Kodverk för ordinationstyp i GetMedicationHistory. Anger om en ordination är en insättnings- eller utsättningsordination. |
| [TypeOfResultCode](CodeSystem-typeofresultcode-cs.md) | Kodverk för typ av resultat (TypeOfResultCodeEnum). Används i GetImagingOutcome och GetReferralOutcome. |

### Terminology: Concept Maps 

These define transformations to convert between codes by systems conforming with this implementation guide.

| | |
| :--- | :--- |
| [GetObservations – observationStatus (SNOMED CT) → FHIR ObservationStatus](ConceptMap-observation-status-map.md) | Mappning från RIVTA GetObservations observationStatus-koder (SNOMED CT, urvals-id 56431000052106) till FHIR R4 ObservationStatus (OBS-003).Kodsystem: SNOMED CT SE, OID 1.2.752.116.2.1.1 → URI http://snomed.info/sct. Om en okänd kod tas emot sätts status till 'unknown' och en OperationOutcome-varning genereras av bryggan. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [Exempel: Provenance med custodian och author](Provenance-SEEHDSProvenanceExample.md) | Visar hur de två agenterna anges så att validering kan avgöra vilken agent som är vilken. |

