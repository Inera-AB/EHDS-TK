# NonReplaceable - Inera EHDS Tjänstekontrakt – FHIR Implementation Guide v0.8.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NonReplaceable**

## CodeSystem: NonReplaceable 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/CodeSystem/nonreplaceable-actoutcome | *Version*:0.8.1 |
| Active as of 2026-11-04 | *Computable Name*:NonReplaceableCS |

 
Kodverk för aktör som har angett att ett läkemedel inte är utbytbart i GetMedicationHistory (DispensationAuthorizationType). 

 This Code system is referenced in the content logical definition of the following value sets: 

* Detta CodeSystem används inte här; det kan användas på andra ställen (t.ex. specifikationer och/eller implementationer som använder detta innehåll)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "nonreplaceable-cs",
  "url" : "https://fhir.inera.se/CodeSystem/nonreplaceable-actoutcome",
  "version" : "0.8.1",
  "name" : "NonReplaceableCS",
  "title" : "NonReplaceable",
  "status" : "active",
  "date" : "2026-11-04T19:17:50+00:00",
  "publisher" : "Inera AB",
  "contact" : [{
    "name" : "Inera AB",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Kodverk för aktör som har angett att ett läkemedel inte är utbytbart i GetMedicationHistory (DispensationAuthorizationType).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "SE",
      "display" : "Sweden"
    }]
  }],
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "Prescriber",
    "display" : "Förskrivare",
    "definition" : "Förskrivaren har angett att läkemedlet inte är utbytbart"
  },
  {
    "code" : "Patient",
    "display" : "Patient",
    "definition" : "Patienten har begärt att läkemedlet inte ska bytas ut"
  }]
}

```
